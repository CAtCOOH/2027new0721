#include <string>
#include <iostream>
using namespace std;
class Car {
private:
    string color;
    int number;
public:
    Car(string c, int n) {
        color = c;
        number = n;
    }
    ~Car(){}
    void display() {
        cout << "锟斤拷一锟斤拷锟斤拷" << " " << "锟斤拷色锟斤拷" << color <<  " " << "锟斤拷锟狡号ｏ拷" << number << endl;
    }
};
int main() {
    Car c1("锟斤拷色", 510721);
    Car c2("锟斤拷色", 919191);
    c1.display();
    c2.display();

}